package com.rakesh.component.akka.example2;

/**
 * Created by ranantoju on 3/11/2017.
 */
public class BlackUser {
    public User blackUser;
    public BlackUser(User blackUser){
        this.blackUser = blackUser;
    }
}
