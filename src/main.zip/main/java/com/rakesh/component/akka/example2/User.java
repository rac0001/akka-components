package com.rakesh.component.akka.example2;

import java.util.Comparator;

/**
 * Created by ranantoju on 3/11/2017.
 */
public class User{
    public String name;
    public String email;

    public User(String name,String email){
        this.name = name;
        this.email= email;
    }
}
