package com.rakesh.component.akka.example2;

/**
 * Created by ranantoju on 3/11/2017.
 */
public class WhiteUser {
    public User whiteUser;
    public WhiteUser(User whiteUser){
        this.whiteUser = whiteUser;
    }
}
