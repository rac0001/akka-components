package com.rakesh.component.akka.state.behaviour;

/**
 * Created by mac on 4/16/17.
 */
public enum EmptyData implements Data{
    EMPTY_DATA
}