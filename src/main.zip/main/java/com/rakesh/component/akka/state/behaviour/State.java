package com.rakesh.component.akka.state.behaviour;

/**
 * Created by mac on 4/16/17.
 */
public enum State {
    IDLE, ACTIVE
}